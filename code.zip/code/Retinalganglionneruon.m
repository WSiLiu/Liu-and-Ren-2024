function  Retinalganglionneruon(I0)
%%%
%I0=f1;
sig_center = [0.32,0.37,0.53,0.21,0.14,0.20,0.16,0.49,0.29,0.29,0.49,0.64,0.42,0.40,0.20,0.24,0.37];
sig_surround = [0.76,2.2,1.6,1.4,3.3,1.4,0.91,3.3,1.6,2.4,3.6,6.4,1.8,4.0,2.9,0.96,1.5];
k = [0.92,0.90,0.95,0.78,0.98,0.73,0.94,0.80,0.90,0.98,0.93,0.90,0.93,0.87,0.95,0.96,0.90]./([2.4,5.9,3.0,6.5,23,7.1,5.7,6.8,5.5,8.5,7.5,10,4.2,10,11,4.0,3.9].^2);
retinal_para.expe_data.sig_center =sig_center;
retinal_para.expe_data.sig_surround = sig_surround;
retinal_para.expe_data.k = k;

[mean1,var1] = normfit(sig_center);
[mean2,var2] = normfit(sig_surround);
[mean3,var3] = normfit(k);
%%%

%I0 = zeros(20,20);%read the image
N_type = 1;%Types of spatial radio;
N_eye = 2;%Types of eyes;
a = 1;d = 5;
N_Retinalneruon =0;
for n_type = 1:N_type
  n1 = a:(n_type*d):size(I0,2);n2 = a:(n_type*d):size(I0,1);
  N_Retinalneruon = N_Retinalneruon +length(n1)*length(n2);
end

for n_eye = 1:N_eye
    ganglion_center = zeros(1,4);
for n_type = 1:N_type
n1=a:(n_type*d):size(I0,2);n2=a:(n_type*d):size(I0,1);
N_Retinalneruon1 = length(n1)*length(n2)+(n_type-1)*size(ganglion_center,1);
n=1+(n_type-1)*size(ganglion_center,1);
if n_type == 1
sig_center_sample=0;sig_surround_sample = 0;
k_sample = 0;
end
while n<=N_Retinalneruon1
    sample1 = -1;sample2 = sample1;sample3 = sample1;
    while sample1<=0
      sample1  = normrnd(mean1,var1,1,1);
    end
    while sample2<=0
      sample2  = normrnd(mean2,var2,1,1);
    end
    while sample3<=0
      sample3  = normrnd(mean3,var3,1,1);
    end
    sig_center_sample(n,1) = sample1;
    sig_surround_sample(n,1) = sample2;
    k_sample(n,1) = n_type*sample3;
    a1 = retinalcenter(n-(n_type-1)*(N_Retinalneruon1- length(n1)*length(n2)),n1,n2,I0,d);
    ganglion_center(n,:) = a1;
    ganglion_center(n,1) = ganglion_center(n,1);
    ganglion_center(n,3) = ganglion_center(n,3);
    n = n+1;
end
end

retinal_para.sample.sig_center =sig_center_sample;
retinal_para.sample.sig_surround = sig_surround_sample;
retinal_para.sample.k = k_sample;
retinal_para.sample.ganglion_center = ganglion_center;
clear name1;clear name2;clear name3;
if n_eye==1
   style = 'left';
else
   style = 'right';
end
name1 = ['retinal_para_',style];
save(name1,'retinal_para');
end
end

