function [MI,NMI] = Neural_NMI(neuralspikes1,neuralspikes2,connection1,connection2)
Res = [];Res1 = [];
for mm = 1:size(neuralspikes1,4)
    % for each situaion,spiking counts of each neuron is measured over situations
    for nn = 1:size(neuralspikes1,1)
        Res = neuralspikes1(nn,1,:,mm);
        if sum(Res(:))~=0
          Res1(nn,:,mm) = Res(:)';
        end
    end 
end
Res = [];Res2 = [];
for mm = 1:size(neuralspikes2,4)
    % for each situaion,spiking counts of each neuron is measured over situations
    for nn = 1:size(neuralspikes2,1)
        Res = neuralspikes2(nn,1,:,mm);
        if sum(Res(:))~=0
          Res2(nn,:,mm) = Res(:)';
        end
    end 
end

bottom1 = min(Res2(:));top1 = max(Res2(:));
edge = (bottom1-0.5):1:(top1+0.5);% range of neural spiking counts
MI = cell(1,size(neuralspikes1,4));NMI = cell(1,size(neuralspikes1,4));
for mm = 1:size(neuralspikes1,4)
    MI0 = [];NMI0 = [];
    % for each situaion,spiking counts of each neuron is measured over situations
    for nn = 1:size(Res1,1)
        for nn1 = 1:size(Res2,1)
            x = Res1(nn,:,mm);
            x = x(:);
            y = Res2(nn1,:,mm);
            y = y(:);
            if (sum(x(:))~=0)&&(sum(y(:))~=0) % the paired neurons with non-empty responses are seleclted
             [mi, nmi] = mutual_info(x, y, edge);
             % connections between paired neurons are considered
             MI0 = [MI0;mi*double(connection1(nn,nn1)||connection2(nn1,nn))];
             NMI0 = [NMI0;nmi*double(connection1(nn,nn1)||connection2(nn1,nn))];
%              MI(nn,nn1,mm) = mi*double(connection1(nn,nn1)||connection2(nn1,nn));
%              NMI(nn,nn1,mm) = nmi*double(connection1(nn,nn1)||connection2(nn1,nn));
            end
        end
    end
    MI{1,mm} = MI0(:);
    NMI{1,mm} = NMI0(:);
    
end

end