function assemble_assemble_response(N_situation,N_assemble,rate_real,assembles)
clear Zleft_rates;
for nn = 1:N_situation
    clear Z_responses0;
    Z_responses0 = rate_real(:,:,:,nn);
    Zleft_rates(:,nn) = mean(mean(Z_responses0,2),3);
end
sparse_assemble = cell(N_assemble,1);figure;
for n1 = 1:N_assemble
    clear neurons;clear Zleft_assemble_responses;
    neurons = assembles{n1,1};
    Z_assemble_ratess = Zleft_rates(neurons,:);
    numerator = mean(Z_assemble_ratess,2).^2;
    denominator = mean(Z_assemble_ratess.^2,2);
    sparse_assemble{n1,1} = numerator./denominator;
    [a0,b0] = hist(sparse_assemble{n1,1}(:));
    a1 = a0./sum(a0);
    subplot(1,3,n1);bar(b0,a1);hold on;
end
end