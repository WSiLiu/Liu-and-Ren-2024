function [mi, NMI] = mutual_info(x, y, edge)   % Calculate empirical probabilities and mutual information for paired variables
    % The continuous variables x and y are discretized to a specified number of bins
    [counts_x, edges_x] = histcounts(x, 'BinEdges', edge);  
    [counts_y, edges_y] = histcounts(y, 'BinEdges', edge);  
    data = [x(:),y(:)];
    % Calculate the joint probability distribution
    ctrs = {edge edge};
    counts_xy = hist3(data,'Ctrs',ctrs);
    pxy = counts_xy / sum(counts_xy(:));
      
    % Calculate the marginal distribution  
    px = counts_x / sum(counts_x);  
    py = counts_y / sum(counts_y);  
      
    % Calculate mutual information  
    mi = 0; 
    for i = 1:length(edges_x) - 1
        for j = 1:length(edges_y) - 1
            if (pxy(i+1,j+1) > 0) && (px(i) > 0) && (py(j) > 0)
                mi = mi + pxy(i+1,j+1) * log2( pxy(i+1,j+1) / (px(i) * py(j)));  
            end  
        end  
    end
    % Calculate entropy
    Hx = 0;
    for i = 1:(length(edges_x) - 1)
        if px(i) > 0
           Hx = Hx - px(i) * log2( px(i) );  
        end
    end
    
    Hy = 0;
    for i = 1:(length(edges_y) - 1)
        if py(i) > 0
           Hy = Hy - py(i) * log2( py(i) );  
        end
    end
%     if ((mi >= 0)&&(Hx >= 0)&&(Hy >= 0)) == 0
%         [double(mi >= 0) double(Hx >= 0) double(Hy >= 0)]
%     end
    % calculate normalized mutual information  
    NMI = 2*mi/(Hx + Hy);

end