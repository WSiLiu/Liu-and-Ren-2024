function Edistance = e_distance(A,B)
  length1 = size(A,2);length2 = size(B,2);
  SUM1 = 0;SUM2 = 0;SUM3 = 0;Edistance=0;
  for n1 = 1:length1
      for n2 = 1:length2
          SUM1 = SUM1+norm((A(:,n1)-B(:,n2)),2);
      end
  end
  for n1 = 1:length1
      for n2 = 1:length1
          SUM2 = SUM2+norm((A(:,n1)-A(:,n2)),2);
      end
  end
  for n1 = 1:length2
      for n2 = 1:length2
          SUM3 = SUM3+norm((B(:,n1)-B(:,n2)),2);
      end
  end
  Edistance=(2/(length1*length2)*(SUM1)-1/(length1*length1)*(SUM2)-1/(length2*length2)*(SUM3))*(length1*length2)/(length1+length2);
end