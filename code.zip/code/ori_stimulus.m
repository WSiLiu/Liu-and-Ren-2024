function ori_stimulus(T,N_cue)
N_sti = 1;
image_length = 50;
s1 = [image_length,image_length];
d = 90;
d1 = 45;
Im0 = zeros(image_length,image_length);
for x = (floor(image_length/2)-5):(floor(image_length/2)+5)
    Im0(x,3:(image_length-2))=1;
end

for ii = 1:N_sti
    for jj = 1:N_cue
    clear I0;clear Im11;
    ii1 = 1;
    I0 = imrotate(Im0,(jj-1)*d,'bicubic');
    center1 = size(I0,1)/2;center2 = size(I0,2)/2;
    x1 = max(floor(center1 - image_length/2),1);
    y1 = max(floor(center2 - image_length/2),1);
    Im11= I0((x1:x1+(image_length-1)),(y1:y1+(image_length-1)));
    I(:,:,ii,jj,ii1) = Im11;
    figure;imshow(Im11);
    end
end


bio_retinal_rate_ori = struct;
clear name1;clear retinal_para_right;
name1 = 'retinal_para_right.mat';
retinal_para_right = load(name1);
N_retinal = size(retinal_para_right.retinal_para.sample.sig_center,1);
rate_retinal = zeros(N_retinal ,2);
for ii = 1:N_sti
    for ii1 = 1:1
     for jj = 1:N_cue
     
     f1 = I(:,:,ii,jj,ii1);
    
    clear name2;clear retinal_para_left;
    name2 = 'retinal_para_left.mat';
    retinal_para_left =load(name2);
    N_retinal = size(retinal_para_left.retinal_para.sample.sig_center,1);
    for n_retinal = 1:N_retinal
        rate_retinal(n_retinal,2) = 0;
        center_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,1:2);
        surround_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,3:4);
        center_sig = retinal_para_left.retinal_para.sample.sig_center(n_retinal,1);
        center_sigma = [center_sig,0;0,center_sig];
        surround_sig = retinal_para_left.retinal_para.sample.sig_surround(n_retinal,1);
        surround_sigma = [surround_sig,0;0,surround_sig];
        k1 = retinal_para_left.retinal_para.sample.k(n_retinal,1);
        for n_x = 1:size(f1,2)
            for n_y = 1:size(f1,1)
                if f1(n_y,n_x)~=0
                p = mvnpdf([n_y,n_x],center_mean,center_sigma)-k1*mvnpdf([n_y,n_x],surround_mean,surround_sigma);
                rate_retinal(n_retinal,2) = rate_retinal(n_retinal,2)+p*f1(n_y,n_x);
                end
            end
        end
    end
    clear name1;
    name1 = ['time',num2str(ii),num2str(jj),num2str(ii1)];
    bio_retinal_rate_ori = setfield(bio_retinal_rate_ori,name1,rate_retinal);
     
     end
    end
end


save 'bio_retinal_rate_ori.mat' -struct bio_retinal_rate_ori;
end