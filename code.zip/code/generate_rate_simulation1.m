function [rate_simulation,cue1] = generate_rate_simulation1(cue_tem,cue_spatial,noisy_stren,N_neuron,T)
         strength = 50;
         clear cue1;
         cue1 = [cue_spatial;cue_tem];

         % cue_tem = 1 indicates simultaneous presentation; cue_tem = 2 indicates non-simultaneous presentation;
         % inputs from visual stimuli
         load('visual_sti.mat'); 
         name = 'visual_sti.mat';
         clear name1;clear rate1;
         name1 = ['time',num2str(1),num2str(cue_spatial),num2str(1)];
         rate1 = cell2mat(struct2cell(load(name,name1)));
         rate_visual = rate1(:,2);

         load('sound_sti.mat');
         name = 'sound_sti.mat';
         clear name2;clear rate1;
         name2 = ['time',num2str(1),num2str(1),num2str(1)];
         rate1 = cell2mat(struct2cell(load(name,name2)));
         rate_sound = rate1(1,1:T);

         
         clear rate_simulation;
         rate_simulation = noisy_stren * rand(2 * N_neuron,2 * T);% basic noisy inputs in simulation
         for t = (T + 1):(2 * T)
             clear rate_sound1;
             if t <=  2*T
                 for n = 1:N_neuron
                   % cue_spacial indicates the direction from which stimuli will come
                   S_delay0 = double(cue_spatial == 1)*(1 - n) + double(cue_spatial == 2)*(n - N_neuron);
                   rate_sound1(n,1) = rate_sound(1, t - T)*exp(S_delay0/N_neuron);

                 end
             else
                 rate_sound1 = zeros(N_neuron,1);
             end
             rate_simulation(:,t) = rate_simulation(:,t) + strength*[rate_visual;rate_sound1];
         end
end