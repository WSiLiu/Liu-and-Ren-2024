function neural_assemble_tem(test_data,net,stimulus,j,L,T0)
%% reaction time
clear RT_mu;clear RT_std;figure;% calculate averaged value and standard deviation of RT for each situation
for m1 = 1:size(stimulus,2)
  clear iden_time
  iden_time = net.iden_t(m1,:);
  plot(m1,iden_time,'o','color',[0.8,0.8,0.8]);hold on;
  RT_mu(m1,1) = mean(iden_time);
  RT_std(m1,1) = std(iden_time);
end
errorbar(RT_mu,RT_std,'*','color',[0.1,0.1,0.1],'LineWidth',1);xlim([0 (size(stimulus,2)+1)]);ylim([-5 50]);
set (gca,'xtick',1:1:size(stimulus,2));

top1 = max(net.iden_t(:));top2 = 0;xrange2 = 0;figure;
fre = [];bins = 1:1:top1;
name1 = [];
for m1 = 1:size(stimulus,2)% frequency histogram of RT for each situation
    clear iden_time;
    iden_time = net.iden_t(m1,3:end);
    [fre(m1,:) ~] = hist(iden_time,bins);
    color = m1*[0.2 0.2 0.2];
    name2 = ['situation',num2str(m1)];
    name1 = [name1;name2];
    h1 = histogram(iden_time,bins,'Facecolor',color);hold on;
    top2 = max(top2,max(fre(m1,:))+10);
    xrange2 = max(xrange2,ceil(max(iden_time(:))+5));
end
ylim([0 top2]);legend(name1);xlim([0 xrange2]);

%% Calculting downstream neural spiking rates for each situation
T1 = T0/2;N_neuron = size(test_data{1,1}.Zt,1);
% Stimulus-induced responses of three groups of ex. neurons
j = 1;clear Z_cout_sti;clear Zleft_cout_sti;clear Zright_cout_sti;
% cout_sti for neural spikes in stimulus duration;
for l_style = 1:size(stimulus,2)
    for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
              if test_data{1,l}.Zt(n,t) == 1
                Z(n,t-(j-1)*T0-T0-T1) = 1;
              end
      end
    end
    Z_cout_sti(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0-T1) = 1;
          end
      end
    end
    Zleft_cout_sti(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+T1+1):(T0+(j-1)*T0+T1+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0-T1) = 1;
          end  
      end
    end
    Zright_cout_sti(:,:,l,l_style) = Zright;
    end
    j = 1+j;
end
% 
j = 1;clear Z_cout_pre;clear Zleft_cout_pre;clear Zright_cout_pre;
% cout_pre for neural spikes in pre-stimulus duration;
for l_style = 1:size(stimulus,2)
   for l = 1:L
    Z = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zt(n,t) == 1
             Z(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Z_cout_pre(:,:,l,l_style) = Z;

    Zleft = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zleftt(n,t) == 1
             Zleft(n,t-(j-1)*T0-T0) = 1;
          end
      end
    end
    Zleft_cout_pre(:,:,l,l_style) = Zleft;

    Zright = zeros(N_neuron,T1);
    for t = (T0+(j-1)*T0+1):(T0+(j-1)*T0+T1)
      for n = 1:N_neuron
          if test_data{1,l}.Zrightt(n,t) == 1
             Zright(n,t-(j-1)*T0-T0) = 1;
          end  
      end
    end
    Zright_cout_pre(:,:,l,l_style) = Zright;
   end
j = 1+j;
end

% neural spiking rates

Zleft_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
Z_rate_real = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
for l = 1:L
for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Zleft_rate_real(n,t,l,l_style) = Zleft_rate_real(n,t,l,l_style)+Zleft_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_real(n,t,l,l_style) = Zright_rate_real(n,t,l,l_style)+Zright_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Z_rate_real(n,t,l,l_style) = Z_rate_real(n,t,l,l_style)+Z_cout_sti(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
end
end
end
Zleft_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Zright_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
Z_rate_pe = zeros(N_neuron,T1,L,size(stimulus,2));
for l_style = 1:size(stimulus,2)
 for l = 1:L
  for t = 1:T1
    for t1 = 1:T1
        for n = 1:N_neuron
            Zleft_rate_pe(n,t,l,l_style) = Zleft_rate_pe(n,t,l,l_style)+Zleft_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Zright_rate_pe(n,t,l,l_style) = Zright_rate_pe(n,t,l,l_style)+Zright_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
            Z_rate_pe(n,t,l,l_style) = Z_rate_pe(n,t,l,l_style)+Z_cout_pre(n,t1,l,l_style)*normpdf(t1-t,0,20);
        end
    end
  end
 end
end
%% save and load neural spiking rates if necessary
% save('Z_rate_pe_tem','Z_rate_pe');save('Z_rate_real_tem','Z_rate_real');
% save('Zleft_rate_pe_tem','Zleft_rate_pe');save('Zleft_rate_real_tem','Zleft_rate_real');
% save('Zright_rate_pe_tem','Zright_rate_pe');save('Zright_rate_real_tem','Zright_rate_real');

%
% aa = load('Z_rate_pe_tem');Z_rate_pe = aa.Z_rate_pe;aa = load('Z_rate_real_tem');Z_rate_real = aa.Z_rate_real;
% aa = load('Zleft_rate_pe_tem');Zleft_rate_pe = aa.Zleft_rate_pe;aa = load('Zleft_rate_real_tem');Zleft_rate_real = aa.Zleft_rate_real;
% aa = load('Zright_rate_pe_tem');Zright_rate_pe = aa.Zright_rate_pe;aa = load('Zright_rate_real_tem');Zright_rate_real = aa.Zright_rate_real;

%% neural variability quenching
% Fano factor and SD of spikes of neural population
Zleft_rate_pe_popu = sum(Zleft_rate_pe,1);
Zright_rate_pe_popu = sum(Zright_rate_pe,1);
Z_rate_pe_popu = sum(Z_rate_pe,1);
Zleft_rate_real_popu =  sum(Zleft_rate_real,1);
Zright_rate_real_popu = sum(Zright_rate_real,1);
Z_rate_real_popu = sum(Z_rate_real,1);
clear Zleft_std_real;clear Zright_std_real;clear Z_std_real;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_real(1,t,l_style) = mean(Zleft_rate_real_popu(1,t,:,l_style));
   Zleft_std_real(1,t,l_style) = std(Zleft_rate_real_popu(1,t,:,l_style));
   Fanoleft_real(1,t,l_style) = (Zleft_std_real(1,t,l_style)^2)/Zleft_mean_real(1,t,l_style);
   Zright_mean_real(1,t,l_style) = mean(Zright_rate_real_popu(1,t,:,l_style));
   Zright_std_real(1,t,l_style) = std(Zright_rate_real_popu(1,t,:,l_style));
   Fanoright_real(1,t,l_style) = (Zright_std_real(1,t,l_style)^2)/Zright_mean_real(1,t,l_style);
   Z_mean_real(1,t,l_style) = mean(Z_rate_real_popu(1,t,:,l_style));
   Z_std_real(1,t,l_style) = std(Z_rate_real_popu(1,t,:,l_style));
   FanoZ_real(1,t,l_style) = (Z_std_real(1,t,l_style)^2)/Z_mean_real(1,t,l_style);
  end
end
clear Zleft_std_pe;clear Zright_std_pe;clear Z_std_pe;
for l_style = 1:size(stimulus,2)
  for t = 1:T1
   Zleft_mean_pe(1,t,l_style) = mean(Zleft_rate_pe_popu(1,t,:,l_style));
   Zleft_std_pe(1,t,l_style) = std(Zleft_rate_pe_popu(1,t,:,l_style));
   Fanoleft_pe(1,t,l_style) = (Zleft_std_pe(1,t,l_style)^2)/Zleft_mean_pe(1,t,l_style);
   Zright_mean_pe(1,t,l_style) = mean(Zright_rate_pe_popu(1,t,:,l_style));
   Zright_std_pe(1,t,l_style) = std(Zright_rate_pe_popu(1,t,:,l_style));
   Fanoright_pe(1,t,l_style) = (Zright_std_pe(1,t,l_style)^2)/Zright_mean_pe(1,t,l_style);
   Z_mean_pe(1,t,l_style) = mean(Z_rate_pe_popu(1,t,:,l_style));
   Z_std_pe(1,t,l_style) = std(Z_rate_pe_popu(1,t,:,l_style));
   FanoZ_pe(1,t,l_style) = (Z_std_pe(1,t,l_style)^2)/Z_mean_pe(1,t,l_style);
  end
end
% plot Fano factor and SD of spikes 1st ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zleft_std_pe,3)
    y1 = [y1,Fanoleft_pe(:,:,n1),Fanoleft_real(:,:,n1)];
end
figure;
plot(x,y1);ylim([0,1.2*max(y1)]);ylabel('Fano Factor');
ylim([0,1.2*max(y1)]);hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
end
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zleft_std_pe,3)
    y1 = [y1,Zleft_std_pe(:,:,n1),Zleft_std_real(:,:,n1)];
end
figure;
plot(x,y1);ylim([0,1.2*max(y1)]);ylabel('SD');
ylim([0,1.2*max(y1)]);hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
end
% plot Fano factor and SD of spikes 2nd ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zright_std_pe,3)
    y1 = [y1,Fanoright_pe(:,:,n1),Fanoright_real(:,:,n1)];
end
figure;
plot(x,y1);ylim([0,1.2*max(y1)]);ylabel('Fano Factor');
ylim([0,1.2*max(y1)]);hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
end
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Zright_std_pe,3)
    y1 = [y1,Zright_std_pe(:,:,n1),Zright_std_real(:,:,n1)];
end
figure;
plot(x,y1);ylim([0,1.2*max(y1)]);ylabel('SD');
ylim([0,1.2*max(y1)]);hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
end
% plot Fano factor and SD of spikes 3rd ex. neural group
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Z_std_pe,3)
    y1 = [y1,FanoZ_pe(:,:,n1),FanoZ_real(:,:,n1)];
end
figure;
plot(x,y1);ylim([0,1.2*max(y1)]);ylabel('Fano Factor');
ylim([0,1.2*max(y1)]);hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
end
x = 1:(size(stimulus,2)*2*T1);y1 = [];
for n1 = 1:size(Z_std_pe,3)
    y1 = [y1,Z_std_pe(:,:,n1),Z_std_real(:,:,n1)];
end
figure;
plot(x,y1);ylim([0,1.2*max(y1)]);ylabel('SD');
ylim([0,1.2*max(y1)]);hold on;xlabel('time step');
for l_style = 1:size(stimulus,2)
    plot([T1+T0*(l_style-1),T1+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
    plot([T0+T0*(l_style-1),T0+T0*(l_style-1)],[0,1.2*max(y1)],'color',[0.5,0.5,0.5]);hold on;
end

% CV of spikes of 1st ex. neurons
N = size(test_data{1,l}.Zleftt,1);
N_sti = size(stimulus,2);
[CV_pe,CV_real] = CV_spikes(Zleft_cout_sti,Zleft_cout_pre,N,T1,L,N_sti);

figure;aa = [];
for l_style = 1:size(stimulus,2)
   plot([1,2],[CV_pe(1,l_style),CV_real(1,l_style)],'-o');hold on
   aa = [aa;'situation',num2str(l_style)];
end
xlim([0,3]);title('CV of ISI of 1st ex. neural group');
set(gca,'XTick',[0.5,1,2,2.5],'xticklabel',{'psedo','','','real'});
legend(aa);

% CV of spikes of 2nd ex. neurons
N = size(test_data{1,l}.Zrightt,1);
Zright_ISI_real = zeros(N,T1,L,size(stimulus,2));
N_sti = size(stimulus,2);
[CV_pe,CV_real] = CV_spikes(Zright_cout_sti,Zright_cout_pre,N,T1,L,N_sti);

figure;aa = [];
for l_style = 1:size(stimulus,2)
   plot([1,2],[CV_pe(1,l_style),CV_real(1,l_style)],'-o');hold on
   aa = [aa;'situation',num2str(l_style)];
end
xlim([0,3]);title('CV of ISI of 2nd ex. neural group');
set(gca,'XTick',[0.5,1,2,2.5],'xticklabel',{'psedo','','','real'});
legend(aa);

% CV of spikes of 3rd ex. neurons
N = size(test_data{1,l}.Zrightt,1);
Z_ISI_real = zeros(N,T1,L,size(stimulus,2));
N_sti = size(stimulus,2);
[CV_pe,CV_real] = CV_spikes(Z_cout_sti,Z_cout_pre,N,T1,L,N_sti);

figure;aa = [];
for l_style = 1:size(stimulus,2)
   plot([1,2],[CV_pe(1,l_style),CV_real(1,l_style)],'-o');hold on
   aa = [aa;'situation',num2str(l_style)];
end
xlim([0,3]);title('CV of ISI of 3rd ex. neural group');
set(gca,'XTick',[0.5,1,2,2.5],'xticklabel',{'psedo','','','real'});
legend(aa);


%% For each downstream neuron, its responsivity is calculated through a Wilcoxon rank-sum test as one attribution
Z_spiketrain_real_avetime = sum(Z_cout_sti,2);
NeuralrespPCA = Z_spiketrain_real_avetime;
% save('NeuralrespPCA1','NeuralrespPCA');
Z_spiketrain_pe_avertime = sum(Z_cout_pre,2);
Z_spiketrain_Wilcoxon_test2 = zeros(size(Z_spiketrain_real_avetime,1),size(Z_spiketrain_real_avetime,4));
for nn = 1:size(Z_spiketrain_real_avetime,1)
    for mm = 1:size(Z_spiketrain_real_avetime,4)
    clear a;clear b;
     a = Z_spiketrain_real_avetime(nn,1,:,mm);
     b = Z_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     Z_spiketrain_Wilcoxon_test2(nn,mm) = h;
    end
end
Zleft_spiketrain_real_avetime = sum(Zleft_cout_sti,2);
Zleft_spiketrain_pe_avertime = sum(Zleft_cout_pre,2);
Zleft_spiketrain_Wilcoxon_test2 = zeros(size(Zleft_spiketrain_real_avetime,1),size(Zleft_spiketrain_real_avetime,4));
for nn = 1:size(Zleft_spiketrain_real_avetime,1)
    for mm = 1:size(Zleft_spiketrain_real_avetime,4)
    clear a;clear b;
     a = Zleft_spiketrain_real_avetime(nn,1,:,mm);
     b = Zleft_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     Zleft_spiketrain_Wilcoxon_test2(nn,mm) = h;
    end
end
Zright_spiketrain_real_avetime = sum(Zright_cout_sti,2);
Zright_spiketrain_pe_avertime = sum(Zright_cout_pre,2);
Zright_spiketrain_Wilcoxon_test2 = zeros(size(Zright_spiketrain_real_avetime,1),size(Zright_spiketrain_real_avetime,4));
for nn = 1:size(Zright_spiketrain_real_avetime,1)
    for mm = 1:size(Zright_spiketrain_real_avetime,4)
    clear a;clear b;
     a = Zright_spiketrain_real_avetime(nn,1,:,mm);
     b = Zright_spiketrain_pe_avertime(nn,1,:,mm);
     [p,h] = ranksum(a(:),b(:));
     Zright_spiketrain_Wilcoxon_test2(nn,mm) = h;
    end
end

% Neural assembles are determined by the Wilcoxon rank-sum test
Zright_assembles = cell(3,1);Zleft_assembles = cell(3,1);Z_assembles = cell(3,1);
Zright_assembles = Neuralassemble(Zright_assembles,Zright_spiketrain_Wilcoxon_test2);
Zleft_assembles = Neuralassemble(Zleft_assembles,Zleft_spiketrain_Wilcoxon_test2);
Z_assembles = Neuralassemble(Z_assembles,Z_spiketrain_Wilcoxon_test2);

figure;
shape = ['o','+','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:10
     n_neuron = n_neuron + 1;
     for m = 1:size(Zright_assembles,1)
            if ~isempty(find(n_neuron == Zright_assembles{m,1}(:)))
               n_assembel = m;
               a = x;b = y;
               plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');


figure;
shape = ['o','+','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:10
     n_neuron = n_neuron + 1;
     for m = 1:size(Zleft_assembles,1)
            if ~isempty(find(n_neuron == Zleft_assembles{m,1}(:)))
               n_assembel = m;
               a = x;b = y;
               plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');
figure;
shape = ['o','+','d','*'];%% For each situation, plot determined neural assembles
n_neuron = 0;
for x = 1:20
  for y = 1:10
     n_neuron = n_neuron + 1;
     for m = 1:size(Z_assembles,1)
            if ~isempty(find(n_neuron == Z_assembles{m,1}(:)))
               n_assembel = m;
               a = x;b = y;
        
               plot(a,b,shape(m),'markersize',8,'color',[0.1 0.1 0.1]+(n_assembel-1)*0.2);hold on;
            end    
    end
  end
end
xlim([0 21]);ylim([0 11]);
set(gca, 'YDir', 'reverse');

%% calcuate contributions of ex. neural groups in causal inference

NeuralrespPCA_Z = Z_spiketrain_real_avetime;
NeuralassemblContri_Z = cell(size(NeuralrespPCA_Z,4),1);
for nn = 1:size(NeuralrespPCA_Z,4)
       Neuralresp0 = [];
       for n1 = 1:size(NeuralrespPCA_Z,1)
           Neuralresp0(n1,:) = NeuralrespPCA_Z(n1,1,:,nn);
       end
       
       a = Neuralresp0';
       b = cov(a);% b is co-variance matrix
       b1 = cov(b);
       [coeff, score, latent, tsquared, explained, mu] = pca(b);
       % coeff returns the principal component coefficients for the N by P data matrix X. Rows of X correspond to observations 
       % and columns to variables. Each column of COEFF contains coefficients
       % for one principal component. 
       % LATENT returns the principal component variances, i.e., the eigenvalues of the covariance matrix of X.

       for n = 1:length(explained)
           c = 0;
           c = sum(explained(1:n,1));
           if c >= 90 % principal components explain 90% of variances are selected
               [n,c]
               N_PCA = n;%N_PCA is the number of principal components
               break
           end 
       end 
   
       [V,D] = eig(b1);
       eigvalue = diag(D);
       [~,idx] = sort(eigvalue,'descend');
       V1 = V(:,idx);
       eigvalue1 = eigvalue(idx);
       D1 = diag(eigvalue1);
   

       % contributions of each row in b are measured 
       radio0 = zeros(size(b,2),N_PCA);
   
       for n = 1:size(b,2) 
           for m = 1:N_PCA 
           clear t;clear lam;clear sig;
           t = coeff(n,m)^2;  
           lam = latent(m);
           sig = sqrt(b1(n,n));
           radio0(n,m) = lam*t/sig;
           end
       
       end
       NeuralassemblContri_Z{nn,1} = radio0;
end

NeuralrespPCA_Zleft = Zleft_spiketrain_real_avetime;
NeuralassemblContri_Zleft = cell(size(NeuralrespPCA_Zleft,4),1);
for nn = 1:size(NeuralrespPCA_Zleft,4)
       Neuralresp0 = [];
       for n1 = 1:size(NeuralrespPCA_Zleft,1)
           Neuralresp0(n1,:) = NeuralrespPCA_Zleft(n1,1,:,nn);
       end
       
       a = Neuralresp0';
       b = cov(a);% b is co-variance matrix
       b1 = cov(b);
       [coeff, score, latent, tsquared, explained, mu] = pca(b);
       % coeff returns the principal component coefficients for the N by P data matrix X. Rows of X correspond to observations 
       % and columns to variables. Each column of COEFF contains coefficients
       % for one principal component. 
       % LATENT returns the principal component variances, i.e., the eigenvalues of the covariance matrix of X.

       for n = 1:length(explained)
           c = 0;
           c = sum(explained(1:n,1));
           if c >= 90 % principal components explain 90% of variances are selected
               [n,c]
               N_PCA = n;%N_PCA is the number of principal components
               break
           end 
       end 
   
       [V,D] = eig(b1);
       eigvalue = diag(D);
       [~,idx] = sort(eigvalue,'descend');
       V1 = V(:,idx);
       eigvalue1 = eigvalue(idx);
       D1 = diag(eigvalue1);
   

       % contributions of each row in b are measured 
       radio0 = zeros(size(b,2),N_PCA);
   
       for n = 1:size(b,2) 
           for m = 1:N_PCA 
           clear t;clear lam;clear sig;
           t = coeff(n,m)^2;  
           lam = latent(m);
           sig = sqrt(b1(n,n));
           radio0(n,m) = lam*t/sig;
           end
       
       end
       NeuralassemblContri_Zleft{nn,1} = radio0;
end

NeuralrespPCA_Zright = Zright_spiketrain_real_avetime;
NeuralassemblContri_Zright = cell(size(NeuralrespPCA_Zright,4),1);
for nn = 1:size(NeuralrespPCA_Zright,4)
       Neuralresp0 = [];
       for n1 = 1:size(NeuralrespPCA_Zright,1)
           Neuralresp0(n1,:) = NeuralrespPCA_Zright(n1,1,:,nn);
       end
       
       a = Neuralresp0';
       b = cov(a);% b is co-variance matrix
       b1 = cov(b);
       [coeff, score, latent, tsquared, explained, mu] = pca(b);
       % coeff returns the principal component coefficients for the N by P data matrix X. Rows of X correspond to observations 
       % and columns to variables. Each column of COEFF contains coefficients
       % for one principal component. 
       % LATENT returns the principal component variances, i.e., the eigenvalues of the covariance matrix of X.

       for n = 1:length(explained)
           c = 0;
           c = sum(explained(1:n,1));
           if c >= 90 % principal components explain 90% of variances are selected
               [n,c]
               N_PCA = n;%N_PCA is the number of principal components
               break
           end 
       end 
   
       [V,D] = eig(b1);
       eigvalue = diag(D);
       [~,idx] = sort(eigvalue,'descend');
       V1 = V(:,idx);
       eigvalue1 = eigvalue(idx);
       D1 = diag(eigvalue1);
   

       % contributions of each row in b are measured 
       radio0 = zeros(size(b,2),N_PCA);
   
       for n = 1:size(b,2) 
           for m = 1:N_PCA 
           clear t;clear lam;clear sig;
           t = coeff(n,m)^2;  
           lam = latent(m);
           sig = sqrt(b1(n,n));
           radio0(n,m) = lam*t/sig;
           end
       
       end
       NeuralassemblContri_Zright{nn,1} = radio0;
end




%% For each situation，calculate contributions of neural assembles
N_assemble = size(Z_assembles,1); % number of neural assembles
N_situation = size(NeuralassemblContri_Z,1); % number of situations

clear Neural_assemb_contri_Zleft;
Neural_assemb_contri_Zleft = zeros(N_situation,N_assemble);
for n_situation = 1:N_situation
  for n_assemble = 1:N_assemble
    % find series numbers of neurons in each assembles
    neuron = [];
    neuron = Zleft_assembles{n_assemble,1}(:);
    neuron = neuron(neuron>0);
    neural_assemb_contri = NeuralassemblContri_Zleft{n_situation,1}(neuron,:);
    % contributions of neural assemble are averaged over selected PCs and neurons
    Neural_assemb_contri_Zleft(n_situation,n_assemble) = mean(neural_assemb_contri(:));%sum(neural_assemb_contri(:));
  end
end
figure;hold on;
h = bar(Neural_assemb_contri_Zleft);
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
end
xlim([0.5 N_situation+0.5]);

clear Neural_assemb_contri_Zright;
Neural_assemb_contri_Zright = zeros(N_situation,N_assemble);
for n_situation = 1:N_situation
    for n_assemble = 1:N_assemble
        % find series numbers of neurons in each assembles
        neuron = [];neural_assemb_contri = [];
        neuron = Zright_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        neural_assemb_contri = NeuralassemblContri_Zright{n_situation,1}(neuron,:);
        % contributions of neural assemble are averaged over selected PCs and neurons
        Neural_assemb_contri_Zright(n_situation,n_assemble) = mean(neural_assemb_contri(:));%sum(neural_assemb_contri(:));
    end
end
figure;hold on;
h = bar(Neural_assemb_contri_Zright);
x = 1:N_situation;
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
    xlim([0.5 N_situation+0.5]);
end


clear Neural_assemb_contri_Z;
Neural_assemb_contri_Z = zeros(N_situation,N_assemble);
for n_situation = 1:N_situation
    for n_assemble = 1:N_assemble
        neuron = [];neural_assemb_contri = [];
        % find series numbers of neurons in each assembles
        neuron = Z_assembles{n_assemble,1}(:);
        neuron = neuron(neuron>0);
        neural_assemb_contri = NeuralassemblContri_Z{n_situation,1}(neuron,:);
        Neural_assemb_contri_Z(n_situation,n_assemble) = mean(neural_assemb_contri(:));
    end
    % total = sum(Neural_assemb_contri_Z(n_situation,:));
    % Neural_assemb_contri_Z(n_situation,:) = Neural_assemb_contri_Z(n_situation,:)./total;
end
figure;hold on;
h = bar(Neural_assemb_contri_Z);
x = 1:N_situation;
color = [0.1,0.1,0.1;0.4,0.4,0.4;0.6,0.6,0.6;0.9,0.9,0.9];
for mm = 1:N_assemble
    h(mm).FaceColor = color(mm,:);
    set(gca,'XTickLabel',[]);
    xlim([0.5 N_situation+0.5]);
end




%% For each pair of downstream neurons, their responding similarity is calculated through the normalized mutual informaiton
Z_spiketrain_real_avetime = sum(Z_cout_sti,2);
Zleft_spiketrain_real_avetime = sum(Zleft_cout_sti,2);
Zright_spiketrain_real_avetime = sum(Zright_cout_sti,2);
% NMI indicates neural responding similarity with connections considered
[MI,NMI_BB] = Neural_NMI(Z_spiketrain_real_avetime,Z_spiketrain_real_avetime,net.VBtoB0,net.VBtoB0);
[MI,NMI_LL] = Neural_NMI(Zleft_spiketrain_real_avetime,Zleft_spiketrain_real_avetime,net.VLtoL0,net.VLtoL0);
[MI,NMI_RR] = Neural_NMI(Zright_spiketrain_real_avetime,Zright_spiketrain_real_avetime,net.VRtoR0,net.VRtoR0);
[MI,NMI_BR] = Neural_NMI(Z_spiketrain_real_avetime,Zright_spiketrain_real_avetime,net.VBtoR0,net.VRtoB0);
[MI,NMI_BL] = Neural_NMI(Z_spiketrain_real_avetime,Zleft_spiketrain_real_avetime,net.VBtoL0,net.VLtoB0);
[MI,NMI_RL] = Neural_NMI(Zright_spiketrain_real_avetime,Zleft_spiketrain_real_avetime,net.VRtoL0,net.VLtoR0);
% Plot error bars of NMI of 3 ex. neural groups
clear mu;clear error;
figure;grid on;
n1 = 1;n2 = 1;% 1st neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_LL(:,:,1);NMI2 = NMI_LL(:,:,2);
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5]);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5]);hold on;grid on;
% x0 = [n1,n1];y0 = [n2,n2];z10 = [mu(n1,n2,1)-error(n1,n2,1),mu(n1,n2,1)+error(n1,n2,1)];plot3(x0,y0,z10,'-','Color',[0.5 0.5 0.5]);hold on;
% x0 = [n1,n1];y0 = [n2,n2];z20 = [mu(n1,n2,2)-error(n1,n2,2),mu(n1,n2,2)+error(n1,n2,2)];plot3(x0,y0,z20,'-','Color',[0.5 0.5 0.5]);hold on;

n1 = 2;n2 = 2;% 2nd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_RR(:,:,1);NMI2 = NMI_RR(:,:,2);
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5]);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5]);hold on;

n1 = 3;n2 = 3;% 3rd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_BB(:,:,1);NMI2 = NMI_BB(:,:,2);
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5]);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5]);hold on;

clear mu;clear error;
n1 = 1;n2 = 2;% 1st and 2nd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_RL(:,:,1);NMI2 = NMI_RL(:,:,2);
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5]);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5]);hold on;

clear mu;clear error;
n1 = 1;n2 = 3;% 1st and 3rd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_BL(:,:,1);NMI2 = NMI_BL(:,:,2);
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5]);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5]);hold on;

clear mu;clear error;
n1 = 2;n2 = 3;% 2nd and 3rd neural groups
clear NMI1;clear NMI2;
NMI1 = NMI_BR(:,:,1);NMI2 = NMI_BR(:,:,2);
mu(n1,n2,1) = mean(NMI1(:));error(n1,n2,1) = std(NMI1(:));
mu(n1,n2,2) = mean(NMI2(:));error(n1,n2,2) = std(NMI2(:));
x = n1;y = n2;z1 = mu(n1,n2,1);z2 = mu(n1,n2,2);
plot3(x,y,z1,'o','Color',[0.5 0.5 0.5]);hold on;plot3(x,y,z2,'*','Color',[0.5 0.5 0.5]);hold on;
xlim([0.5 3.5]);ylim([0.5 3.5]);
xticks([1 2 3]);yticks([1 2 3]);
%% For downstream neural groups, their interactions are calculated through Pearson correlation coefficient
N_situation = size(stimulus,2);
p_LR = neural_correlation(N_situation,T1,Zleft_rate_real_popu,Zright_rate_real_popu);
p_LB = neural_correlation(N_situation,T1,Zleft_rate_real_popu,Z_rate_real_popu);
p_RB = neural_correlation(N_situation,T1,Zright_rate_real_popu,Z_rate_real_popu);
for mm = 1:N_situation
    figure;
    aa = [];
    t = 1:T1;
    x1 = p_LR(:,mm);
    plot(t,x1,'color',[0.2,0.2,0.2]);
    aa = [aa;'between 1st and 2nd groups'];
    hold on;
    x2 = p_LB(:,mm);
    plot(t,x2,'color',[0.5,0.5,0.5]);
    aa = [aa;'between 1nd and 3rd groups'];
    hold on;
    x3 = p_RB(:,mm);
    plot(t,x3,'color',[0.8,0.8,0.8]);
    aa = [aa;'between 2nd and 3rd groups'];
    legend(aa);
    xlabel('time step');title('Neural interactions')
end


Zleft_rate_real_assemble = cell(size(Zleft_assembles,1),N_situation);
for n1 = 1:size(Zleft_assembles,1)
    neuron = Zleft_assembles{n1,1}(:);
    for n = 1:N_situation
        Zleft_rate_real_assemble{n1,n} = Zleft_rate_real(neuron,:,:,n);
    end
end
Zright_rate_real_assemble = cell(size(Zright_assembles,1),N_situation);
for n1 = 1:size(Zright_assembles,1)
    neuron = Zright_assembles{n1,1}(:);
    for n = 1:N_situation
        Zright_rate_real_assemble{n1,n} = Zright_rate_real(neuron,:,:,n);
    end
end
Z_rate_real_assemble = cell(size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    neuron = Z_assembles{n1,1}(:);
    for n = 1:N_situation
        Z_rate_real_assemble{n1,n} = Z_rate_real(neuron,:,:,n);
    end
end

p_assemble_LR = cell(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        figure;
        aa = [];
        for n = 1:N_situation
            spikes1 = sum(Zleft_rate_real_assemble{n1,n},1);
            spikes2 = sum(Zright_rate_real_assemble{n2,n},1);
            x1 = neural_correlation(1,T1,spikes1,spikes2);
            p_assemble_LR{n1,n2,n} = x1;
            t = 1:T1;
            plot(t,x1,'color',[0.2,0.2,0.2]+(n-1)*0.5);
            hold on;
            aa = [aa;'between 1st group assemble ',num2str(n1),' and 2nd group assemble ',num2str(n2)];
        end
        legend(aa);
        xlabel('time step');title('Neural interactions')
    end
end
p_assemble_LB = cell(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            spikes1 = sum(Zleft_rate_real_assemble{n1,n},1);
            spikes2 = sum(Z_rate_real_assemble{n2,n},1);
            x1 = neural_correlation(1,T1,spikes1,spikes2);
            p_assemble_LB{n1,n2,n} = x1;
        end
    end
end
p_assemble_RB = cell(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            spikes1 = sum(Zright_rate_real_assemble{n1,n},1);
            spikes2 = sum(Z_rate_real_assemble{n2,n},1);
            x1 = neural_correlation(1,T1,spikes1,spikes2);
            p_assemble_RB{n1,n2,n} = x1;
        end
    end
end

% correlation between assembles averaged over neurons and time steps
p_Assemble_LR = zeros(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            clear p0;
            p0 = p_assemble_LR{n1,n2,n};
            p_Assemble_LR(n1,n2,n) = mean(p0(:));
        end
    end
end
p_Assemble_RB = zeros(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            clear p0;
            p0 = p_assemble_RB{n1,n2,n};
            p_Assemble_RB(n1,n2,n) = mean(p0(:));
        end
    end
end
p_Assemble_LB = zeros(size(Z_assembles,1),size(Z_assembles,1),N_situation);
for n1 = 1:size(Z_assembles,1)
    for n2 = 1:size(Z_assembles,1)
        for n = 1:N_situation
            clear p0;
            p0 = p_assemble_LB{n1,n2,n};
            p_Assemble_LB(n1,n2,n) = mean(p0(:));
        end
    end
end

p_Assemble0 = [p_Assemble_LR(:);p_Assemble_RB(:);p_Assemble_LB(:)];
top0 = max(p_Assemble0(:));bottom0 = min(p_Assemble0(:));

Plot_neural_assemble_interact(top0,bottom0,Z_assembles,Zleft_assembles,p_Assemble_LB,N_situation);
Plot_neural_assemble_interact(top0,bottom0,Zright_assembles,Zleft_assembles,p_Assemble_LR,N_situation);
Plot_neural_assemble_interact(top0,bottom0,Z_assembles,Zright_assembles,p_Assemble_RB,N_situation);

% Energy between neural assembles in bi-direction communition
% L&R


Energy_assemble_LR = Energy_Assemble(Zleft_cout_sti,Zright_cout_sti,net.VRtoL0,net.VLtoR0,Zleft_assembles,Zright_assembles);
Energy_assemble_BR = Energy_Assemble(Z_cout_sti,Zright_cout_sti,net.VRtoB0,net.VBtoR0,Z_assembles,Zright_assembles);
Energy_assemble_LB = Energy_Assemble(Zleft_cout_sti,Z_cout_sti,net.VBtoL0,net.VLtoB0,Zleft_assembles,Z_assembles);

N_assemble = size(Zleft_assembles,1);N_situation = 2;
t = 1:T1;% temporal communicating energy between neural assembles
for nn1 = 1:N_assemble
    for nn2 = 1:N_assemble
        n_situation = 1;% in 1st situation
        energy_assemble11 = Energy_assemble_LR{nn1,nn2,n_situation,1};% from nn2 to nn1
        energy_assemble21 = Energy_assemble_LR{nn2,nn1,n_situation,2};% from nn1 to nn2
        figure;
        plot(t,energy_assemble11,'.-','Color',[0.2 0.2 0.2]);hold on;plot(t,energy_assemble21,'.-','Color',[0.8 0.8 0.8]);hold on;
        n_situation = 2;% in 2nd situation
        energy_assemble12 = Energy_assemble_LR{nn1,nn2,n_situation,1};
        energy_assemble22 = Energy_assemble_LR{nn2,nn1,n_situation,2};
        plot(t,energy_assemble12,'*-','Color',[0.2 0.2 0.2]);hold on;plot(t,energy_assemble22,'*-','Color',[0.8 0.8 0.8]);hold on;
    
    end
end
% 
% Plot_neural_assemble_energy(N_assemble,Energy_assemble_LR);
% Plot_neural_assemble_energy(N_assemble,Energy_assemble_BR);
% Plot_neural_assemble_energy(N_assemble,Energy_assemble_LB);

% Stimulus modification of neural responses

stimulus_modification_assemble_response(N_situation,N_assemble,Zleft_rate_real,Zleft_assembles);
stimulus_modification_assemble_response(N_situation,N_assemble,Zright_rate_real,Zright_assembles);
stimulus_modification_assemble_response(N_situation,N_assemble,Z_rate_real,Z_assembles);

% Stimulus-induced neural variability
stimulus_induced_assemble_variability(N_assemble,Zleft_rate_real,Zleft_assembles);
stimulus_induced_assemble_variability(N_assemble,Zright_rate_real,Zright_assembles);
stimulus_induced_assemble_variability(N_assemble,Z_rate_real,Z_assembles);


end